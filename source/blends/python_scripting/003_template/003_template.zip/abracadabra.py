# #############################
# Simple Sensor, Controller and Actuator Demo
# #############################
# This file is part of the book:
# "Game Development with Blender"
# by Dalai Felinto and Mike Pan
#
# Published by "CENGAGE Learning" in 2013
#
# You are free to use-it, modify it and redistribute
# as long as you keep the original credits when pertinent.
#
# File adapted and tested with UPBGE 0.3
#
# Copyright - February 2013
# This work is licensed under the Creative Commons
# Attribution-Share Alike 3.0 Unported License
# #############################

import bge
from bge import logic

# Use bge module to get/set game property + transform
cont = logic.getCurrentController()
owner = cont.owner
scene = logic.getCurrentScene()
objects = scene.objects
font_object = objects["Text"]

# Use bpy.types.TextCurve attributes to set other text settings (size, body, etc)
font_object_data = font_object.blenderObject.data

sens = cont.sensors['my_sensor']
act = cont.actuators['my_actuator']

if sens.positive:
  cont.activate(act)
  font_object_data.body = "CADABRA"
  font_object_data.size = 2
  font_object_data.resolution_u = 1
else:
  cont.deactivate(act)
  font_object_data.body = "ABRA"
  font_object_data.size = 1
  font_object_data.resolution_u = 4

